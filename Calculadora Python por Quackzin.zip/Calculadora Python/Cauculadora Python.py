while True:
    primeira_parcela = int(input("Digite a primeira parcela da sua operação: "))
    operador = int(input("Digite o operador: 1 = +, 2 = -, 3 = *, 4 = /: "))
    segunda_parcela = int(input("Digite a segunda parcela da sua operação: "))

    if operador == 1:
        print("A resposta da operação é", primeira_parcela + segunda_parcela)

    elif operador == 2:
        print("A resposta da operação é", primeira_parcela - segunda_parcela)

    elif operador == 3:
        print("A resposta da operação é", primeira_parcela * segunda_parcela)

    elif operador == 4:
        if segunda_parcela == 0:
            print("É impossível dividir por zero.")
        else:
            print("A resposta da operação é", primeira_parcela / segunda_parcela)

    else:
        print("Operador inválido.")

    sair = input("Quer fazer outra operação? (s/n): ")
    if sair.lower() == "n":
        break


