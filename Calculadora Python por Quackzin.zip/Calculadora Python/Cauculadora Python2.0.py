while True:
    print("\n=== CALCULADORA PYTHON ===")
    print("1 - Soma (+)")
    print("2 - Subtração (-)")
    print("3 - Multiplicação (*)")
    print("4 - Divisão (/)")
    print("0 - Sair")

    operador = int(input("Escolha uma opção: "))

    if operador == 0:
        print("Encerrando o programa. Até mais!")
        break

    if operador < 0 or operador > 4:
        print("Opção inválida.")
        continue

    primeira_parcela = float(input("Digite a primeira parcela: "))
    segunda_parcela = float(input("Digite a segunda parcela: "))

    try:
        if operador == 1:
            resultado = primeira_parcela + segunda_parcela

        elif operador == 2:
            resultado = primeira_parcela - segunda_parcela

        elif operador == 3:
            resultado = primeira_parcela * segunda_parcela

        elif operador == 4:
            resultado = primeira_parcela / segunda_parcela

        if resultado.is_integer():
            print("Resultado:", int(resultado))
        else:
            print("Resultado:", resultado)

    except ZeroDivisionError:
        print("É impossível dividir por zero.")
